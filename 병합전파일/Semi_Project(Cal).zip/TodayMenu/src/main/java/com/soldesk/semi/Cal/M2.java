package com.soldesk.semi.Cal;

import javax.servlet.http.HttpServletRequest;

public class M2 {

	public static void Calc(HttpServletRequest request) {
		// TODO Auto-generated method stub
		
		
		int p2 = Integer.parseInt(request.getParameter("people2"));
	
	
	}

	
	}


