package com.soldesk.semi.Cal;

import javax.servlet.http.HttpServletRequest;

public class M {

	public static void Calc(HttpServletRequest request) {
		// 값 얻기
		
		int c =Integer.parseInt(request.getParameter("cost"));
		int p = Integer.parseInt(request.getParameter("people"));
		int result = c/p;
		
		System.out.println(result);
		
		Remain r = new Remain();
		r.setC(c);
		r.setP(p);
		r.setR(result);
		
		request.setAttribute("rr", r);
		
		
	}

}
