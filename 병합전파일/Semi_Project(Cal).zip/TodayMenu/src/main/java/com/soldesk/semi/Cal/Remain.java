package com.soldesk.semi.Cal;

public class Remain {

	private int c;
	private int p;
	private int r;
	
	private void remain() {
		// TODO Auto-generated method stub

	}

	public Remain(int c, int p, int r) {
		super();
		this.c = c;
		this.p = p;
		this.r = r;
	}

	public Remain() {
		// TODO Auto-generated constructor stub
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	
	
	
	
	
	
	
}
