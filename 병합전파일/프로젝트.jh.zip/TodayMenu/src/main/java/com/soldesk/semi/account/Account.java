package com.soldesk.semi.account;

import java.util.Date;

// bean, dto, vo, pojo

public class Account {
	private String id;
	private String pw;
	private String name;
	private String birth;
	private String addr;
	private String phone;
	private String qestion;
	private String answer;
	
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public Account(String id, String pw, String name, String birth, String addr, String phone, String qestion,
			String answer) {
		super();
		this.id = id;
		this.pw = pw;
		this.name = name;
		this.birth = birth;
		this.addr = addr;
		this.phone = phone;
		this.qestion = qestion;
		this.answer = answer;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getQestion() {
		return qestion;
	}

	public void setQestion(String qestion) {
		this.qestion = qestion;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}


	
	
	
}
