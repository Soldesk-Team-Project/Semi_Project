package com.soldesk.semi.account;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.jni.File;


import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class AccountDAO {

	
	public static void loginCheck(HttpServletRequest request) {
		
		HttpSession hs = request.getSession();
		Account a = (Account) hs.getAttribute("accountInfo");
		
		if(a == null) {
			// �α��� ����
			request.setAttribute("loginPage", "account/login.jsp");
			request.setAttribute("r", "�α��� ����?");
		} else {
			// �α��� ����
			request.setAttribute("loginPage", "account/loginOK.jsp");
		}
	
	}
	
	
	public static void login(HttpServletRequest request) {
		String userId = request.getParameter("id");
		String userPw = request.getParameter("pw");
		
		//��������� ����Ǹ� ���� �ְ� �ƴϸ� ������
		String idd =(String) request.getAttribute("idd");	
		String pww =(String) request.getAttribute("pww");	
		
		if (idd !=null) {
			userId = idd;
			userPw = pww;
		}
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql = "select * from ACCOUNT1 where a_id = ?";
			
			con = DBManager.connect();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userId);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				String dbPW = rs.getString("a_pw");
				

			
				if (userPw.equals(dbPW)) {
					// ���� �������ϱ� ���ļ�
					Account a = new Account();
					a.setId(rs.getString("a_id"));
					a.setPw(rs.getString("a_pw"));
					a.setName(rs.getString("a_name"));
					a.setAddr(rs.getString("a_addr"));
					a.setPhone(rs.getString("a_phone"));
					a.setBirth(rs.getString("a_birth"));
					a.setQestion(rs.getString("a_qestion"));
					a.setAnswer(rs.getString("a_answer"));
				
					
					System.out.println(rs.getString("a_pw"));;
					System.out.println(rs.getString("a_birth"));;
					System.out.println("�׽�Ʈ��");
					System.out.println(a);
					
					HttpSession hs = request.getSession();
					hs.setAttribute("accountInfo", a);
					hs.setMaxInactiveInterval(60000);
					//�ʴ����� �ϴ� 1000��
					
					
//					request.setAttribute("a", a);
					
					request.setAttribute("r", "�α��� ����!");
				} else {
					request.setAttribute("r", "��й�ȣ ����!");
				}
			} else {
				request.setAttribute("r", "�������� �ʴ� ȸ�� �Դϴ�");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(con, pstmt, rs);
		}

	}


	public static void logOut(HttpServletRequest request) {
		// �α׾ƿ� �ϴ� ��
		// ������ ������.
		//	���ʿ� ����������� ������, ������ �ð��� ���� �Ǿ�����.
		HttpSession hs = request.getSession();
		hs.setAttribute("accountInfo", null);
//		hs.removeAttribute("accountInfo");
		
		request.setAttribute("r", "�α׾ƿ� ����");
		
		
	}


	public static void reg(HttpServletRequest request) {
		
		Connection con = null;
		PreparedStatement  pstmt = null;
		String sql = "insert into ACCOUNT1 values (?,?,?,?,?,?,?,?)";
		try {
			request.setCharacterEncoding("UTF-8");
			con = DBManager.connect();
			pstmt = con.prepareStatement(sql);

	
		String id =	request.getParameter("id");
		String pw =	request.getParameter("pw");
		String name =	request.getParameter("name");
		String birth = request.getParameter("birth");
		String addr =	request.getParameter("addr");
		String phone =	request.getParameter("phone");
		String qestion =	request.getParameter("qestion");
		String answer =	request.getParameter("answer");


		
	System.out.println(id);
	System.out.println(pw);
	System.out.println(name);
	System.out.println(birth);
	System.out.println(addr);
	System.out.println(phone);	
	System.out.println(qestion);
	System.out.println(answer);

		pstmt.setString(1, id);
		pstmt.setString(2, pw);
		pstmt.setString(3, name);
		pstmt.setString(4,birth);
		pstmt.setString(5, addr);
		pstmt.setString(6, phone);
		pstmt.setString(7, qestion);
		pstmt.setString(8, answer);
	
				
		if (pstmt.executeUpdate()==1) {
			System.out.println("reg��ϼ���");
		}
		else {
			System.out.println("reg��Ͻ���");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			DBManager.close(con, pstmt, null);
		}
	}


	public static void updateAccount(HttpServletRequest request) {
		Connection con = null;
		PreparedStatement  pstmt = null;
		String sql = "update  ACCOUNT1 set a_name=?,a_pw=?,a_addr=?,a_phone=?,a_qestion=?,a_answer=?  where a_id=?";
		try {
			request.setCharacterEncoding("UTF-8");
			con = DBManager.connect();
			pstmt = con.prepareStatement(sql);
			

		String name =request.getParameter("name");
		String pw =	request.getParameter("pw");
		String pw2 =request.getParameter("pw2");	
		String addr =request.getParameter("addr");
		String phone =request.getParameter("phone");
		String qestion =request.getParameter("qestion");
		String answer =request.getParameter("answer");
	
		
	System.out.println(name);
	System.out.println(pw);
	System.out.println(pw2);
	System.out.println(addr);
	System.out.println(phone);
	System.out.println(qestion);
	System.out.println(answer);

		pstmt.setString(1, name);
		
		if (pw2.length()==0) {
			pstmt.setString(2, pw);
			
		}
		else {
		pstmt.setString(2, pw2);
		}
		pstmt.setString(3, addr);
		pstmt.setString(4, phone);
		pstmt.setString(5, qestion);
		pstmt.setString(6, answer);		
		pstmt.setString(7, request.getParameter("id"));
		
		request.setAttribute("idd", request.getParameter("id"));
		request.setAttribute("pww", pw2);
		//�佺���� ���ǹ� �־���� ���ݾ��� pw3
		if (pstmt.executeUpdate()==1) {
			System.out.println("update��ϼ���");
			
		}
		else {
			System.out.println("update��Ͻ���");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			DBManager.close(con, pstmt, null);
		}
	}

	
	



	public static void deletAccount(HttpServletRequest request) {

		Connection con = null;
		PreparedStatement  pstmt = null;
		String sql = "delete ACCOUNT1 where a_id=?";
		System.out.println(sql);
		try {
			
			con = DBManager.connect();
			pstmt = con.prepareStatement(sql);
			String id = request.getParameter("id");
			pstmt.setString(1,id);
			
			System.out.println(id);
			
			if(pstmt.executeUpdate()==1) {
			System.out.println("Ż�𼺰�");
			}
		}
		
		catch (Exception e) {
		
			e.printStackTrace();
		}
		finally {
			
			DBManager.close(con, pstmt, null);
		}
	}


	public static void findid(HttpServletRequest request) {

		Connection con = null;
		PreparedStatement  pstmt = null;
		String sql = "select * from ACCOUNT1 where a_name=? and a_birth=? and a_qestion=? and a_answer=?";

		ResultSet rs = null;
		try {
			request.setCharacterEncoding("UTF-8");
			con = DBManager.connect();
			pstmt = con.prepareStatement(sql);
		


		String name =request.getParameter("name");
		String birth =request.getParameter("birth");	
		String qestion =request.getParameter("qestion");
		String answer =request.getParameter("answer");
	
		
	System.out.println(name);
	System.out.println(birth);
	System.out.println(qestion);
	System.out.println(answer);

		pstmt.setString(1, name);
		pstmt.setString(2, birth);
		pstmt.setString(3, qestion);
		pstmt.setString(4, answer);
		rs = pstmt.executeQuery();

		if (rs.next()) {
			
			Account find = new Account();
			find.setId(rs.getString("a_id"));
			find.setPw(rs.getString("a_pw"));
			find.setName(rs.getString("a_name"));
			find.setAddr(rs.getString("a_addr"));
			find.setPhone(rs.getString("a_phone"));
			find.setBirth(rs.getString("a_birth"));
			find.setQestion(rs.getString("a_qestion"));
			find.setAnswer(rs.getString("a_answer"));
			
			
			
			System.out.println("find����");
			request.setAttribute("find", find);
		}
	
		else {
			System.out.println("find����");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			DBManager.close(con, pstmt, null);
		}
		
	}
	
	public static void findpw(HttpServletRequest request) {

		Connection con = null;
		PreparedStatement  pstmt = null;
		String sql = "select * from ACCOUNT1 where a_id=? and a_qestion=? and a_answer=?";

		ResultSet rs = null;
		try {
			request.setCharacterEncoding("UTF-8");
			con = DBManager.connect();
			pstmt = con.prepareStatement(sql);
		


		String id =request.getParameter("id");
		String qestion =request.getParameter("qestion");
		String answer =request.getParameter("answer");
	
		
	System.out.println(id);
	System.out.println(qestion);
	System.out.println(answer);

		pstmt.setString(1, id);
		pstmt.setString(2, qestion);
		pstmt.setString(3, answer);
		rs = pstmt.executeQuery();

		if (rs.next()) {
			
			Account find = new Account();
			find.setId(rs.getString("a_id"));
			find.setPw(rs.getString("a_pw"));
			find.setName(rs.getString("a_name"));
			find.setAddr(rs.getString("a_addr"));
			find.setPhone(rs.getString("a_phone"));
			find.setBirth(rs.getString("a_birth"));
			find.setQestion(rs.getString("a_qestion"));
			find.setAnswer(rs.getString("a_answer"));
			
			
			
			System.out.println("findpw����");
			request.setAttribute("find", find);
		}
	
		else {
			System.out.println("findpw����");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			DBManager.close(con, pstmt, null);
		}
	}
}