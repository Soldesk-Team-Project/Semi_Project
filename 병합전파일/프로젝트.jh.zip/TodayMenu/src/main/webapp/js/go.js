function deleteAccount(i){
	
	let ok = confirm('정말 탈퇴해?');
	
	if(ok){
		
		
	location.href='DeleteAccountC?id=' +i
	}
	
	
}