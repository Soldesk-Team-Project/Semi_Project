create table account1(
a_id varchar2(30 char) primary key,
a_pw varchar2(30 char) not null,
a_name varchar2(20 char) not null,
a_birth varchar2(30 char) not null,
a_addr varchar2(100 char)  not null,
a_phone varchar2(30 char) not null,
a_qestion varchar2(100 char) not null,
a_answer varchar2(100 char) not null
);

insert into ACCOUNT1 values ('id','pw','jh','1996-05-14','�ּ�','����','����','�亯')

select * from ACCOUNT1 
select * from ACCOUNT1 where a_name= 'jh'and a_qestion='����' and a_answer='�亯'


