package com.soldesk.semi.cal;

public class Remain {

	private int c;
	private int p;
	private int r;

	public Remain(int c, int p, int r) {
		super();
		this.c = c;
		this.p = p;
		this.r = r;
	}

	public Remain() {}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}
}
