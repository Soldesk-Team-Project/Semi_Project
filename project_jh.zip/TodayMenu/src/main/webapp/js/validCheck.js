// JS 활용한 유효성 검사 lib 완성!
	
// 일반적으로 입력값의 유효성을 검사하는 것들
// 함수형태로 정리해놓기 (나중에 쓰려고)
// .jar 라이브러리 쓰는 것 처럼

	// 문제가 있으면 true, 없으면 false

// <input>을 넣으면..
	// 거기에 글자가 없으면 true 있으면 false
function isEmpty() {
	alert("pw 값을 넣어라");
	return !pw.value // 값이 없으면 과 같음
}


// <input>랑 글자수를 넣으면..
	// 입력한 글자수 보다 적으면 true 아니면 false
function lessThan(input, length) {
	return input.value.length < length;
}


// <input>을 넣으면
	// 한글, 특수문자 들어있으면 true, 없으면 false
function containKR() {
	// 너무 많으니까 되는거만 적어놓기
	let ok = "qwertyuiopasdfgjklzxcvbnmQWERTYUIOPASDFGJKLZXCVBNM1234567890@._";
	
	for (let i = 0; i < input.value.length; i++) {
		// 사용자가 input에 입력한 값을 하나씩 반복해서 검사한다.
		if (ok.indexOf(input.value[i]) == -1) {
			return true;
		}
	}
}

function containID(id) {
	// id는 영어소문자 , 숫자만 가능
	let ok = "qwertyuiopasdfgjklzxcvbnm1234567890";
	
	for (let i = 0; i < id.value.length; i++) {
		// 사용자가 input에 입력한 값을 하나씩 반복해서 검사한다.
		if (ok.indexOf(input.value[i]) == -1) {
			return true;
		}
	}
}
// <input> x 2개 넣으면 
	// 내용이 다르면 true, 아니면 false
function notEquals(pw, pw2) {
	
	 
	if (pw.value != pw2.value) {
            alert("두 비밀번호가 맞지 않습니다.");
            form.password1.value = "";
            form.password2.value = "";
            form.password2.focus();
            return false;
	}
return false;
	
}


// <input>, 문자열 세트
	// 그 문자열 세트가 포함 안되있으면 true
	// 들어있으면 false
function notContains(input, set) {
	// set : 0123456789 -> 숫자를 반드시 포함
	// set : QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm -> 영문을 반드시 포함
	
	for (let i = 0; i < set.length; i++) {
		if (input.value.indexOf(set[i]) != -1) {
			return false;
		}		
	}
	// 돌려보고 포함되지 않았으면 true로 넘겨서 에러로 잡는다.
	return true;
}

// <input> 을 넣으면
	// 숫자가 아니면 true, 숫자면 false
function isNotNumber(input) {
	return isNaN(input.value);
}











